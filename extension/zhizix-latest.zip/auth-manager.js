/**
 * 智子X - 平台认证管理器
 * Copyright (c) 2026 zhiziX
 * GitHub: https://github.com/zhiziX/zhizix-extension
 *
 * 管理多平台的认证状态，通过适配器模式支持不同平台的登录检测和 Cookie 管理。
 * 支持平台：微信公众号、B站、抖音、小红书、快手
 */

const AUTH_EXPIRY_MS = 4 * 24 * 60 * 60 * 1000 // 4 天

const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'

export class AuthManager {
  constructor() {
    /** @type {Map<string, import('./platforms/_base.js').PlatformAdapter>} */
    this.adapters = new Map()
    this._statusCache = new Map()
    this._cacheTimeout = 1000 // 1秒缓存
    this._registerBuiltinPlatforms()
  }

  _registerBuiltinPlatforms() {
    const platforms = [
      {
        id: 'xiaohongshu',
        name: '小红书',
        domain: 'www.xiaohongshu.com',
        homeUrl: 'https://www.xiaohongshu.com/',
        cookieUrl: 'https://www.xiaohongshu.com/',
        strategy: 'none',  // 静默 fetch 自动使用浏览器 Cookie，无需认证
      },
      {
        id: 'bilibili',
        name: '哔哩哔哩',
        domain: 'www.bilibili.com',
        homeUrl: 'https://www.bilibili.com/',
        cookieUrl: 'https://www.bilibili.com/',
        strategy: 'none',  // 直接 fetch 页面 HTML 解析，无需认证
      },
      {
        id: 'douyin',
        name: '抖音',
        domain: 'www.douyin.com',
        homeUrl: 'https://www.douyin.com/',
        cookieUrl: 'https://www.douyin.com/',
        strategy: 'inject_execute',  // 抖音 API 有反爬签名，必须在平台页面内 fetch
        checkLogin(cookieStr) {
          return { loggedIn: cookieStr.includes('login_time') || cookieStr.includes('passport_auth_mix_state') }
        },
        buildHeaders(cookieStr) {
          const headers = {
            'User-Agent': USER_AGENT,
            'Referer': 'https://www.douyin.com/',
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'Origin': 'https://www.douyin.com',
          }
          if (cookieStr) headers['Cookie'] = cookieStr
          return headers
        },
      },
      {
        id: 'kuaishou',
        name: '快手',
        domain: 'www.kuaishou.com',
        homeUrl: 'https://www.kuaishou.com/',
        cookieUrl: 'https://www.kuaishou.com/',
        strategy: 'none',  // 直接 fetch 页面 HTML 解析，无需认证
      },
      {
        id: 'wechat',
        name: '微信公众号',
        domain: 'mp.weixin.qq.com',
        homeUrl: 'https://mp.weixin.qq.com/',
        cookieUrl: 'https://mp.weixin.qq.com/',
        strategy: 'cookie_fetch',
        checkLogin(cookieStr) {
          return { loggedIn: cookieStr.includes('slave_sid=') }
        },
        buildHeaders(cookieStr) {
          return {
            'Cookie': cookieStr,
            'Referer': 'https://mp.weixin.qq.com/',
            'User-Agent': USER_AGENT,
          }
        },
      },
    ]

    for (const p of platforms) {
      this.adapters.set(p.id, p)
    }
  }

  /** 获取平台配置 */
  getPlatformConfig(platformId) {
    return this.adapters.get(platformId) || null
  }

  /** 获取所有平台 ID */
  listPlatformIds() {
    return [...this.adapters.keys()]
  }

  /** 获取所有平台认证状态 */
  async getAllPlatformStatus() {
    const results = []
    for (const [id, adapter] of this.adapters) {
      const status = await this.getAuthStatus(id)
      results.push({ id, name: adapter.name, ...status })
    }
    return results
  }

  /** 查询单个平台认证状态 */
  async getAuthStatus(platformId) {
    // 检查缓存
    const cached = this._statusCache.get(platformId)
    if (cached && Date.now() - cached.timestamp < this._cacheTimeout) {
      return cached.data
    }

    const adapter = this.adapters.get(platformId)
    if (!adapter) return { error: `Unknown platform: ${platformId}` }

    // 微信公众号特殊处理：仅验证认证状态（哑管道模式）
    if (platformId === 'wechat') {
      const data = await chrome.storage.local.get(['wechatToken', 'wechatExpires', 'wechatNickname', 'wechatAvatar'])
      if (data.wechatToken && data.wechatExpires > Date.now()) {
        const result = {
          connected: true,
          username: data.wechatNickname || '',
          avatar: data.wechatAvatar || ''
        }
        this._statusCache.set(platformId, { data: result, timestamp: Date.now() })
        return result
      }
      // 微信未登录，直接返回未连接状态，不检查浏览器 cookie
      const result = { connected: false }
      this._statusCache.set(platformId, { data: result, timestamp: Date.now() })
      return result
    }

    // 小红书特殊处理：读取专用存储
    if (platformId === 'xiaohongshu') {
      const data = await chrome.storage.local.get(['xiaohongshuCookie', 'xiaohongshuExpires', 'xiaohongshuNickname', 'xiaohongshuAvatar'])
      if (data.xiaohongshuCookie && data.xiaohongshuExpires > Date.now()) {
        return {
          connected: true,
          username: data.xiaohongshuNickname || '',
          avatar: data.xiaohongshuAvatar || ''
        }
      }
      // 小红书未登录，直接返回未连接状态，不检查浏览器 cookie
      return { connected: false }
    }

    // B站和快手无需认证（直接 fetch 页面解析），始终返回无需连接
    if (platformId === 'bilibili' || platformId === 'kuaishou') {
      return { connected: false }
    }

    // 优先读取缓存的认证数据
    const key = `auth_${platformId}`
    const stored = await chrome.storage.local.get(key)
    const authData = stored[key]

    if (authData && authData.expires > Date.now()) {
      return { connected: true, username: authData.username || '', avatar: authData.avatar || '' }
    }

    // 缓存过期或不存在，从浏览器 cookie 检测
    const cookieStr = await this.getCookieForPlatform(platformId)
    const loginCheck = adapter.checkLogin(cookieStr)

    if (loginCheck.loggedIn) {
      const data = {
        connected: true,
        cookie: cookieStr,
        username: loginCheck.username || '',
        avatar: loginCheck.avatar || '',
        expires: Date.now() + AUTH_EXPIRY_MS,
      }
      await chrome.storage.local.set({ [key]: data })
      return { connected: true, username: data.username, avatar: data.avatar }
    }

    return { connected: false }
  }

  /** 验证微信 token 是否有效 */
  async _validateWechatToken(token) {
    try {
      const tabs = await chrome.tabs.query({ url: 'https://mp.weixin.qq.com/*' })
      if (tabs.length === 0) return true // 没有打开的标签页，无法验证，假定有效

      const results = await chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: async (tk) => {
          try {
            const url = `https://mp.weixin.qq.com/cgi-bin/home?t=home/index&token=${tk}&lang=zh_CN`
            const resp = await fetch(url, { credentials: 'include' })
            const html = await resp.text()
            return !html.includes('账号登录') && !html.includes('请重新登录')
          } catch { return true }
        },
        args: [token]
      })
      return results?.[0]?.result ?? true
    } catch {
      return true // 验证失败，假定有效
    }
  }

  /** 从微信公众号页面提取昵称和头像 */
  async _extractWechatProfile() {
    const tabs = await chrome.tabs.query({ url: 'https://mp.weixin.qq.com/*' })
    if (tabs.length === 0) return { nickname: '', avatar: '' }

    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: async () => {
          try {
            const p = new URLSearchParams(window.location.search)
            let token = p.get('token') || ''
            if (!token) {
              const m = document.cookie.match(/token=(\d+)/)
              if (m) token = m[1]
            }
            const url = 'https://mp.weixin.qq.com/cgi-bin/home?t=home/index'
              + (token ? '&token=' + token : '') + '&lang=zh_CN'
            const resp = await fetch(url, { credentials: 'include', redirect: 'follow' })
            const html = await resp.text()
            const nm = html.match(/wx\.cgiData\.nick_name\s*?=\s*?"([^"]+)"/)
            const am = html.match(/wx\.cgiData\.head_img\s*?=\s*?"([^"]+)"/)
            return { nickname: nm ? nm[1] : '', avatar: am ? am[1] : '' }
          } catch { return { nickname: '', avatar: '' } }
        }
      })
      return results?.[0]?.result || { nickname: '', avatar: '' }
    } catch {
      return { nickname: '', avatar: '' }
    }
  }

  /** 发起平台连接（打开标签页让用户登录） */
  async connect(platformId, helpers) {
    const adapter = this.adapters.get(platformId)
    if (!adapter) return { error: `Unknown platform: ${platformId}` }

    // 如果适配器有自定义连接流程（如微信扫码），使用它
    if (adapter.onConnect) {
      return await adapter.onConnect(helpers)
    }

    // 默认流程：打开平台首页，激活标签页让用户手动登录
    const tabId = await helpers.ensureTab(platformId)
    await chrome.tabs.update(tabId, { active: true })

    return { ok: true, message: '已打开平台页面，请登录后返回检查状态' }
  }

  /** 断开平台连接 */
  async disconnect(platformId) {
    // 清除缓存
    this._statusCache.delete(platformId)

    // 微信公众号特殊处理
    if (platformId === 'wechat') {
      await chrome.storage.local.remove(['wechatToken', 'wechatExpires', 'wechatNickname', 'wechatAvatar', '_profileExtractAttempted'])
      return { ok: true }
    }

    // 小红书特殊处理
    if (platformId === 'xiaohongshu') {
      await chrome.storage.local.remove(['xiaohongshuCookie', 'xiaohongshuExpires', 'xiaohongshuNickname', 'xiaohongshuAvatar'])
      return { ok: true }
    }

    const key = `auth_${platformId}`
    await chrome.storage.local.remove(key)
    return { ok: true }
  }

  /** 获取平台 cookie 字符串（用于代理请求） */
  async getCookieForPlatform(platformId) {
    const adapter = this.adapters.get(platformId)
    if (!adapter) return null

    // 抖音特殊处理：使用登录时保存的完整 cookie
    // （chrome.cookies.getAll 无法获取页面 JS 动态生成的 msToken、bd_ticket_guard 等关键 cookie）
    if (platformId === 'douyin') {
      const data = await chrome.storage.local.get('auth_douyin')
      if (data.auth_douyin?.cookie) {
        return data.auth_douyin.cookie
      }
    }

    // 其他平台：始终读取最新浏览器 cookie，避免使用过期缓存
    return await this._readCookies(adapter.cookieUrl)
  }

  /** 从浏览器 cookie jar 读取指定 URL 的所有 cookie */
  async _readCookies(url) {
    const cookies = await chrome.cookies.getAll({ url })
    return cookies.map(c => `${c.name}=${c.value}`).join('; ')
  }
}
