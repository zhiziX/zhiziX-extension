/**
 * 智子X - 浏览器扩展
 * Copyright (c) 2026 zhiziX
 * GitHub: https://github.com/zhiziX/zhizix-extension
 *
 * Service Worker 主模块
 *
 * 功能说明：
 * 1. 平台认证管理 - 管理微信、B站、抖音等平台的登录状态
 * 2. 跨域请求处理 - 作为浏览器扩展转发网页到平台API的请求
 * 3. AI 请求转发 - 转发网页到用户配置的AI API的请求（哑管道模式）
 *
 * 数据流向：用户网页 → 本扩展（透明转发）→ 目标平台/AI API
 * 隐私承诺：不记录、不存储、不上传任何用户数据
 */

import { AuthManager } from './auth-manager.js'

const authManager = new AuthManager()

// ============================================================================
// 1. 通用工具函数
// ============================================================================

/** 等待标签页加载完成（最多 15 秒）
 * 使用位置：ensurePlatformTab, ensureWechatLoginTab
 */
function waitForTabLoad(tabId) {
  return new Promise((resolve) => {
    const timeout = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener)
      resolve()
    }, 15000)

    function listener(id, info) {
      if (id === tabId && info.status === 'complete') {
        clearTimeout(timeout)
        chrome.tabs.onUpdated.removeListener(listener)
        resolve()
      }
    }
    chrome.tabs.onUpdated.addListener(listener)
  })
}

/** 拼接 URL 查询参数
 * 使用位置：handlePlatformRequest
 */
function buildFetchUrl(url, query) {
  if (!query) return url
  const params = new URLSearchParams()
  for (const [k, v] of Object.entries(query)) {
    params.set(k, String(v))
  }
  const sep = url.includes('?') ? '&' : '?'
  return url + sep + params.toString()
}

/** 构建 fetch options
 * 使用位置：handlePlatformRequest
 */
function buildFetchOptions(method, body) {
  const options = { method, credentials: 'include' }
  if (body && method !== 'GET') {
    options.body = JSON.stringify(body)
    options.headers = { 'Content-Type': 'application/json' }
  }
  return options
}

// ============================================================================
// 2. 平台标签页管理（通用）
// ============================================================================

/** 缓存各平台的标签页 ID */
const platformTabs = {}

/** 确保指定平台有一个可用的标签页
 * 使用位置：消息路由 platform_connect, handlePlatformRequest
 */
async function ensurePlatformTab(platformId) {
  const config = authManager.getPlatformConfig(platformId)
  if (!config) throw new Error(`Unknown platform: ${platformId}`)

  // 检查缓存的标签页是否还存在
  if (platformTabs[platformId]) {
    try {
      const tab = await chrome.tabs.get(platformTabs[platformId])
      if (tab && tab.url && tab.url.includes(config.domain)) {
        return platformTabs[platformId]
      }
    } catch {
      platformTabs[platformId] = null
    }
  }

  // 查找已有的平台标签页
  const existing = await chrome.tabs.query({ url: `https://${config.domain}/*` })
  if (existing.length > 0) {
    platformTabs[platformId] = existing[0].id
    return platformTabs[platformId]
  }

  // 创建新的后台标签页
  const tab = await chrome.tabs.create({ url: config.homeUrl, active: false })
  platformTabs[platformId] = tab.id
  await waitForTabLoad(tab.id)
  return tab.id
}

/** 在平台标签页中执行函数（用于 inject_execute 策略）
 * 使用位置：消息路由 platform_connect, handlePlatformRequest
 */
async function executeInPlatformTab(platformId, func, args = []) {
  const tabId = await ensurePlatformTab(platformId)
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',  // 在页面上下文执行，使 fetch 经过页面的反爬拦截器（如抖音的 a_bogus 签名）
    func,
    args,
  })
  if (!results || results.length === 0) {
    throw new Error('executeScript returned no results')
  }
  return results[0].result
}

// ============================================================================
// 3. 微信公众号登录管理
// ============================================================================

let wechatLoginTabId = null
let wechatLoginWindowId = null
let wechatLoginActive = false

/** 确保微信登录标签页存在
 * 使用位置：executeInWechatTab
 */
async function ensureWechatLoginTab() {
  // 检查缓存的 tab 是否仍然有效
  if (wechatLoginTabId != null && wechatLoginWindowId != null) {
    try {
      const tab = await chrome.tabs.get(wechatLoginTabId)
      if (tab && tab.windowId === wechatLoginWindowId) return wechatLoginTabId
    } catch {
      wechatLoginTabId = null
      wechatLoginWindowId = null
    }
  }

  // 如果登录流程未激活，不自动创建新窗口
  if (!wechatLoginActive) {
    throw new Error('Login window closed by user')
  }

  // 创建最小化窗口
  const win = await chrome.windows.create({
    url: 'https://mp.weixin.qq.com/cgi-bin/home?t=home/index&lang=zh_CN',
    state: 'minimized',
    focused: false,
  })
  wechatLoginWindowId = win.id
  wechatLoginTabId = win.tabs[0].id
  await waitForTabLoad(wechatLoginTabId)
  return wechatLoginTabId
}

/** 在微信登录标签页中执行函数
 * 使用位置：消息路由 wechat_login_* 系列
 */
async function executeInWechatTab(func, args = []) {
  const tabId = await ensureWechatLoginTab()
  const results = await chrome.scripting.executeScript({ target: { tabId }, func, args })
  if (!results || results.length === 0) throw new Error('executeScript returned no results')
  return results[0].result
}

/** 关闭微信登录窗口
 * 使用位置：消息路由 wechat_login_complete, wechat_login_cancel, wechat_logout
 */
function closeWechatLoginWindow() {
  wechatLoginActive = false
  if (wechatLoginWindowId != null) {
    try { chrome.windows.remove(wechatLoginWindowId) } catch (e) {}
  }
  wechatLoginTabId = null
  wechatLoginWindowId = null
}

/** 读取微信 Cookie
 * 使用位置：消息路由 get_wechat_cookie, wechat_login_complete
 */
async function readWechatCookies() {
  const cookies = await chrome.cookies.getAll({ url: 'https://mp.weixin.qq.com/' })
  return cookies.map(c => `${c.name}=${c.value}`).join('; ')
}

// ============================================================================
// ============================================================================
// 5. 平台请求代理
// ============================================================================

/** 代理平台请求（附加用户 cookie，绕过 CORS）
 * 使用位置：消息路由 platform_request
 */
async function handlePlatformRequest(msg) {
  const { platform, url, method = 'GET', query, body } = msg

  const adapter = authManager.getPlatformConfig(platform)
  if (!adapter) return { error: `Unknown platform: ${platform}` }

  // 检查连接状态（抖音使用 inject_execute，小红书使用静默 fetch，跳过认证检查）
  // B站和快手已改为专用 fetch 处理器（bilibili_fetch / kuaishou_fetch），不经过此函数
  const COOKIE_OPTIONAL_PLATFORMS = ['douyin', 'xiaohongshu']
  if (!COOKIE_OPTIONAL_PLATFORMS.includes(platform)) {
    const status = await authManager.getAuthStatus(platform)

    if (!status.connected) {
      return { error: '未连接到该平台，请先登录', needAuth: true }
    }
  }

  // inject_execute 策略：在平台标签页中执行 fetch
  if (adapter.strategy === 'inject_execute') {
    const result = await executeInPlatformTab(platform, async (fetchUrl, fetchOptions) => {
      try {
        const resp = await fetch(fetchUrl, {
          ...fetchOptions,
          headers: {
            ...fetchOptions.headers,
            'Accept': 'application/json, text/plain, */*',
            'Referer': window.location.href,
          }
        })
        const text = await resp.text()
        return { status: resp.status, data: text }
      } catch (e) {
        return { error: e.message }
      }
    }, [buildFetchUrl(url, query), buildFetchOptions(method, body)])
    return result
  }

  // cookie_fetch 策略：在 Service Worker 中直接 fetch
  const cookieStr = await authManager.getCookieForPlatform(platform)
  const headers = adapter.buildHeaders ? adapter.buildHeaders(cookieStr) : {
    'Cookie': cookieStr,
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  }

  const fetchUrl = buildFetchUrl(url, query)
  const fetchOptions = { method, headers }
  if (body && method !== 'GET') {
    fetchOptions.body = JSON.stringify(body)
    headers['Content-Type'] = 'application/json'
  }

  try {
    const resp = await fetch(fetchUrl, fetchOptions)
    const text = await resp.text()
    return { status: resp.status, data: text }
  } catch (e) {
    console.error('[Platform Request] Fetch error:', e)
    return { error: e.message }
  }
}

/** 下载二进制资源（图片/视频），返回 base64
 * 使用位置：消息路由 fetch_url
 */
async function fetchUrl(msg) {
  let { url, headers = {} } = msg
  if (url.startsWith('//')) {
    url = 'https:' + url
  }
  try {
    const resp = await fetch(url, { headers })
    const buffer = await resp.arrayBuffer()
    const bytes = new Uint8Array(buffer)
    let binary = ''
    for (let i = 0; i < bytes.length; i++) {
      binary += String.fromCharCode(bytes[i])
    }
    return {
      status: resp.status,
      data: btoa(binary),
      contentType: resp.headers.get('content-type') || 'application/octet-stream',
    }
  } catch (e) {
    return { error: e.message }
  }
}

// ============================================================================
// 6. 后台任务队列系统（Background Task Queue System）
// ============================================================================

const AI_TASKS_KEY = 'aiTasks'
const MAX_TASK_AGE = 24 * 60 * 60 * 1000  // 24小时

/** 生成任务ID */
function generateTaskId() {
  return `task_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`
}

/** 获取所有任务 */
async function getAllTasks() {
  const { aiTasks = {} } = await chrome.storage.local.get(AI_TASKS_KEY)
  return aiTasks
}

/** 保存任务 */
async function saveTask(taskId, task) {
  const tasks = await getAllTasks()
  tasks[taskId] = task
  await chrome.storage.local.set({ aiTasks: tasks })
}

/** 删除任务 */
async function deleteTask(taskId) {
  const tasks = await getAllTasks()
  delete tasks[taskId]
  await chrome.storage.local.set({ aiTasks: tasks })
}

/** 清理过期任务 */
async function cleanupOldTasks() {
  const tasks = await getAllTasks()
  const now = Date.now()
  let changed = false
  for (const [id, task] of Object.entries(tasks)) {
    if (now - task.createdAt > MAX_TASK_AGE) {
      delete tasks[id]
      changed = true
    }
  }
  if (changed) {
    await chrome.storage.local.set({ aiTasks: tasks })
  }
}

/** 处理AI任务 */
async function processAiTask(taskId) {
  const tasks = await getAllTasks()
  const task = tasks[taskId]
  if (!task || task.status !== 'pending') return

  task.status = 'processing'
  task.startedAt = Date.now()
  await saveTask(taskId, task)

  try {
    const { url, method = 'POST', headers = {}, body } = task.request
    const resp = await fetch(url, { method, headers, body: body || undefined })
    const text = await resp.text()

    task.status = 'completed'
    task.result = { status: resp.status, data: text }
    task.completedAt = Date.now()

    // 记录模型统计
    await recordModelStats(task.request, task.result)
  } catch (e) {
    task.status = 'failed'
    task.error = e.message
    task.completedAt = Date.now()
    console.error('[Task Queue] Failed:', taskId, e.message)
  }

  await saveTask(taskId, task)
}

/** 记录模型调用统计 */
async function recordModelStats(request, result) {
  try {
    const body = request.body ? JSON.parse(request.body) : {}
    const model = body.model || 'unknown'

    // 解析 token 使用信息
    let tokens = null
    try {
      const responseData = JSON.parse(result.data)
      // OpenAI / DeepSeek / Grok 格式
      if (responseData.usage) {
        tokens = {
          prompt: responseData.usage.prompt_tokens || 0,
          completion: responseData.usage.completion_tokens || 0,
          total: responseData.usage.total_tokens || 0
        }
      }
      // Claude 格式
      else if (responseData.usage) {
        tokens = {
          prompt: responseData.usage.input_tokens || 0,
          completion: responseData.usage.output_tokens || 0,
          total: (responseData.usage.input_tokens || 0) + (responseData.usage.output_tokens || 0)
        }
      }
    } catch (e) {
      // 无法解析响应，跳过 token 统计
    }

    const { modelStats = {} } = await chrome.storage.local.get('modelStats')
    if (!modelStats[model]) {
      modelStats[model] = {
        count: 0,
        tokens: { prompt: 0, completion: 0, total: 0 },
        lastUsed: Date.now()
      }
    }

    modelStats[model].count++
    if (tokens) {
      modelStats[model].tokens.prompt += tokens.prompt
      modelStats[model].tokens.completion += tokens.completion
      modelStats[model].tokens.total += tokens.total
    }
    modelStats[model].lastUsed = Date.now()

    await chrome.storage.local.set({ modelStats })
  } catch (e) {
    console.error('[Stats] Failed to record:', e)
  }
}

/** 提交AI任务 */
async function submitAiTask(request) {
  const taskId = generateTaskId()
  const task = {
    taskId,
    type: 'ai_request',
    status: 'pending',
    request,
    result: null,
    error: null,
    createdAt: Date.now(),
    startedAt: null,
    completedAt: null,
  }

  await saveTask(taskId, task)

  // 立即开始处理
  processAiTask(taskId).catch(e => console.error('[Task Queue] Process error:', e))

  return { taskId }
}

// 启动时清理过期任务
cleanupOldTasks()

// ============================================================================
// 7. AI API 代理（兼容旧接口）
// ============================================================================

/** 非流式 AI API 代理
 * 使用位置：消息路由 ai_proxy
 */
async function handleAiProxy(msg) {
  const { url, method = 'POST', headers = {}, body } = msg
  try {
    const resp = await fetch(url, { method, headers, body: body || undefined })
    const text = await resp.text()
    return { status: resp.status, data: text }
  } catch (e) {
    return { error: e.message }
  }
}

/** 流式 AI API 代理 */
chrome.runtime.onConnectExternal.addListener((port) => {
  if (port.name !== 'ai_stream') return
  port.onMessage.addListener(async (msg) => {
    if (msg.type !== 'ai_proxy') return
    const { url, method = 'POST', headers = {}, body } = msg
    try {
      const resp = await fetch(url, { method, headers, body: body || undefined })
      if (!resp.ok) {
        const text = await resp.text()
        port.postMessage({ type: 'error', status: resp.status, data: text })
        return
      }
      const reader = resp.body.getReader()
      const decoder = new TextDecoder()
      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        port.postMessage({ type: 'chunk', data: decoder.decode(value, { stream: true }) })
      }
      port.postMessage({ type: 'done' })
    } catch (e) {
      port.postMessage({ type: 'error', message: e.message })
    }
  })
})

// ============================================================================
// 8. 消息路由
// ============================================================================

// 监听外部消息（来自网页）
chrome.runtime.onMessageExternal.addListener((msg, _sender, sendResponse) => {
  handleMessage(msg)
    .then(sendResponse)
    .catch(e => sendResponse({ error: e.message }))
  return true
})

// 监听内部消息（来自 popup）
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  handleMessage(msg)
    .then(sendResponse)
    .catch(e => sendResponse({ error: e.message }))
  return true
})

async function handleMessage(msg) {
  switch (msg.type) {
    // ========== 通用消息 ==========

    case 'ping':
      return {
        ok: true,
        version: '1.0.0',
        platforms: authManager.listPlatformIds(),
      }

    case 'get_platforms':
      return { platforms: await authManager.getAllPlatformStatus() }

    case 'platform_auth_status':
      return await authManager.getAuthStatus(msg.platform)

    case 'platform_connect':
      return await authManager.connect(msg.platform, {
        ensureTab: ensurePlatformTab,
        executeInTab: executeInPlatformTab,
      })

    case 'platform_disconnect':
      return await authManager.disconnect(msg.platform)

    case 'platform_request':
      return await handlePlatformRequest(msg)

    // B站专用 fetch：SW 直接 fetch 视频页面 HTML（含重定向跟随）
    // 页面内联 __INITIAL_STATE__（元数据）和 __playinfo__（视频流URL），无需 WBI 签名或 Cookie
    case 'bilibili_fetch': {
      try {
        const resp = await fetch(msg.url, {
          redirect: 'follow',
          headers: {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9',
          },
        })
        const text = await resp.text()
        return { status: resp.status, data: text }
      } catch (e) {
        console.error('[bilibili_fetch] Error:', e)
        return { error: e.message }
      }
    }

    // 快手专用 fetch：使用移动端 UA 直接 fetch（含重定向跟随）
    // 原因：快手根据 UA 决定返回桌面版（空 APOLLO_STATE）还是移动版（含完整数据的 INIT_STATE）
    // 关键：Chrome SW fetch() 无法覆盖 User-Agent / Sec-* 等受保护头（Fetch 规范 forbidden headers）
    //       必须使用 declarativeNetRequest 在网络层注入移动端头
    case 'kuaishou_fetch': {
      const MOBILE_UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1'
      const KS_UA_RULE_ID = 9999
      try {
        // 临时添加 declarativeNetRequest 规则，在网络层覆盖 UA
        await chrome.declarativeNetRequest.updateDynamicRules({
          removeRuleIds: [KS_UA_RULE_ID],
          addRules: [{
            id: KS_UA_RULE_ID,
            priority: 1,
            action: {
              type: 'modifyHeaders',
              requestHeaders: [
                { header: 'User-Agent', operation: 'set', value: MOBILE_UA },
                { header: 'Sec-CH-UA-Mobile', operation: 'set', value: '?1' },
                { header: 'Sec-CH-UA-Platform', operation: 'set', value: '"iOS"' },
              ],
            },
            condition: {
              requestDomains: ['kuaishou.com', 'chenzhongtech.com', 'kuaishou.cn'],
            },
          }],
        })

        const resp = await fetch(msg.url, {
          redirect: 'follow',
          headers: {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9',
          },
        })
        const text = await resp.text()
        return { status: resp.status, data: text }
      } catch (e) {
        console.error('[kuaishou_fetch] Error:', e)
        return { error: e.message }
      } finally {
        // 立即清除临时规则，避免影响其他请求
        await chrome.declarativeNetRequest.updateDynamicRules({
          removeRuleIds: [KS_UA_RULE_ID],
        }).catch(() => {})
      }
    }

    // 小红书专用 fetch：SW 直接 fetch 笔记页面 HTML（不带 Cookie）
    // 页面内联 __INITIAL_STATE__（YAML 格式），未登录状态也返回完整数据
    // 如果失败，前端会自动降级到 cookie_fetch（需要登录）
    case 'xhs_fetch': {
      try {
        const resp = await fetch(msg.url, {
          redirect: 'follow',
          headers: {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9',
          },
        })
        const text = await resp.text()
        return { status: resp.status, data: text }
      } catch (e) {
        console.error('[xhs_fetch] Error:', e)
        return { error: e.message }
      }
    }

    case 'ai_proxy':
      return await handleAiProxy(msg)

    // ========== 后台任务队列 ==========

    case 'submit_ai_task':
      return await submitAiTask(msg.request)

    case 'get_ai_task': {
      const tasks = await getAllTasks()
      return tasks[msg.taskId] || { error: 'Task not found' }
    }

    case 'list_ai_tasks':
      return { tasks: await getAllTasks() }

    case 'delete_ai_task':
      await deleteTask(msg.taskId)
      return { success: true }

    case 'cancel_ai_task': {
      const tasks = await getAllTasks()
      const task = tasks[msg.taskId]
      if (task && task.status === 'processing') {
        task.status = 'failed'
        task.error = 'Cancelled by user'
        task.completedAt = Date.now()
        await saveTask(msg.taskId, task)
        return { success: true }
      }
      return { success: false, error: 'Task not found or not processing' }
    }

    // ========== 通用工具 ==========

    case 'fetch_url':
      return await fetchUrl(msg)

    case 'resolve_redirect': {
      const { url } = msg
      try {
        // 创建隐藏tab来跟随重定向
        const tab = await chrome.tabs.create({ url, active: false })

        // 等待页面加载完成
        await new Promise((resolve) => {
          const listener = (tabId, info) => {
            if (tabId === tab.id && info.status === 'complete') {
              chrome.tabs.onUpdated.removeListener(listener)
              resolve()
            }
          }
          chrome.tabs.onUpdated.addListener(listener)

          // 超时保护
          setTimeout(() => {
            chrome.tabs.onUpdated.removeListener(listener)
            resolve()
          }, 5000)
        })

        // 获取最终URL
        const finalTab = await chrome.tabs.get(tab.id)
        const finalUrl = finalTab.url

        // 关闭tab
        await chrome.tabs.remove(tab.id)

        return { url: finalUrl }
      } catch (e) {
        return { error: e.message }
      }
    }

    // ========== 微信公众号登录 ==========

    case 'get_wechat_cookie': {
      const cookie = await readWechatCookies()
      return { cookie }
    }

    case 'get_wechat_token': {
      const { wechatToken } = await chrome.storage.local.get('wechatToken')
      if (wechatToken) return { token: wechatToken }

      const tokenTabs = await chrome.tabs.query({ url: 'https://mp.weixin.qq.com/*' })
      if (tokenTabs.length > 0) {
        const results = await chrome.scripting.executeScript({
          target: { tabId: tokenTabs[0].id },
          func: () => {
            try {
              const p = new URLSearchParams(window.location.search)
              const t = p.get('token')
              if (t) return t
              if (window.wx?.commonData?.token) {
                return String(window.wx.commonData.token)
              }
              return null
            } catch { return null }
          },
        })
        const t = results?.[0]?.result
        if (t) {
          await chrome.storage.local.set({ wechatToken: t })
          return { token: t }
        }
      }
      return { error: '未登录，请先扫码登录公众号后台' }
    }

    case 'get_wechat_profile': {
      const profTabs = await chrome.tabs.query({ url: 'https://mp.weixin.qq.com/*' })
      if (profTabs.length > 0) {
        const results = await chrome.scripting.executeScript({
          target: { tabId: profTabs[0].id },
          func: async () => {
            try {
              const p = new URLSearchParams(window.location.search)
              let token = p.get('token') || ''
              if (!token) {
                const m = document.cookie.match(/token=(\d+)/)
                if (m) token = m[1]
              }
              const url = 'https://mp.weixin.qq.com/cgi-bin/home?t=home/index'
                + (token ? '&token=' + token : '') + '&lang=zh_CN'
              const resp = await fetch(url, { credentials: 'include', redirect: 'follow' })
              const html = await resp.text()
              const nm = html.match(/wx\.cgiData\.nick_name\s*?=\s*?"([^"]+)"/)
              const am = html.match(/wx\.cgiData\.head_img\s*?=\s*?"([^"]+)"/)
              return { nickname: nm ? nm[1] : '', avatar: am ? am[1] : '' }
            } catch { return { nickname: '', avatar: '' } }
          },
        })
        return results?.[0]?.result || { nickname: '', avatar: '' }
      }
      return { nickname: '', avatar: '' }
    }

    case 'wechat_login_start': {
      wechatLoginActive = true
      const result = await executeInWechatTab(async (sid) => {
        try {
          const url = 'https://mp.weixin.qq.com/cgi-bin/bizlogin?action=startlogin'
          const body = new URLSearchParams({
            userlang: 'zh_CN', redirect_url: '', login_type: '3',
            sessionid: sid, token: '', lang: 'zh_CN', f: 'json', ajax: '1',
          })
          const resp = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body.toString(),
            credentials: 'include',
          })
          return { status: resp.status, data: await resp.text() }
        } catch (e) {
          return { error: e.message }
        }
      }, [msg.sid || ''])
      if (result.error) throw new Error(result.error)
      return result
    }

    case 'wechat_login_qrcode': {
      const result = await executeInWechatTab(async () => {
        try {
          const url = 'https://mp.weixin.qq.com/cgi-bin/scanloginqrcode?action=getqrcode&random=' + Date.now()
          const resp = await fetch(url, { credentials: 'include' })
          const buffer = await resp.arrayBuffer()
          if (buffer.byteLength === 0) return { error: '二维码响应为空' }
          const bytes = new Uint8Array(buffer)
          let binary = ''
          for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i])
          const ct = resp.headers.get('Content-Type') || 'image/jpeg'
          return { base64: 'data:' + ct + ';base64,' + btoa(binary) }
        } catch (e) {
          return { error: e.message }
        }
      })
      if (result.error) throw new Error(result.error)
      return result
    }

    case 'wechat_login_scan': {
      const result = await executeInWechatTab(async () => {
        try {
          const url = 'https://mp.weixin.qq.com/cgi-bin/scanloginqrcode?action=ask&token=&lang=zh_CN&f=json&ajax=1'
          const resp = await fetch(url, { credentials: 'include' })
          return JSON.parse(await resp.text())
        } catch (e) {
          return { error: e.message }
        }
      })
      if (result.error) throw new Error(result.error)
      return result
    }

    case 'wechat_login_complete': {
      const result = await executeInWechatTab(async () => {
        try {
          const url = 'https://mp.weixin.qq.com/cgi-bin/bizlogin?action=login'
          const body = new URLSearchParams({
            userlang: 'zh_CN', redirect_url: '', cookie_forbidden: '0',
            cookie_cleaned: '0', plugin_used: '0', login_type: '3',
            token: '', lang: 'zh_CN', f: 'json', ajax: '1',
          })
          const resp = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body.toString(),
            credentials: 'include',
          })
          return { status: resp.status, data: await resp.text() }
        } catch (e) {
          return { error: e.message }
        }
      })
      if (result.error) throw new Error(result.error)

      const respData = JSON.parse(result.data)
      let token = ''
      if (respData.redirect_url) {
        const m = respData.redirect_url.match(/token=(\d+)/)
        if (m) token = m[1]
      }

      const fullCookie = await readWechatCookies()
      const expires = Date.now() + 4 * 24 * 60 * 60 * 1000

      let nickname = '', avatar = ''
      if (!token) {
        try {
          const pageInfo = await executeInWechatTab(async () => {
            try {
              const resp = await fetch('https://mp.weixin.qq.com/cgi-bin/home?t=home/index&lang=zh_CN', {
                credentials: 'include', redirect: 'follow',
              })
              const finalUrl = resp.url
              const html = await resp.text()
              const urlMatch = finalUrl.match(/token=(\d+)/)
              const jsMatch = html.match(/token\s*[:=]\s*["']?(\d+)["']?/)
              const nm = html.match(/<div class="weui-desktop-name">([^<]+)<\/div>/)
              const am = html.match(/<img[^>]+class="weui-desktop-account__img"[^>]+src="([^"]+)"/)
              return {
                tokenFromUrl: urlMatch ? urlMatch[1] : '',
                tokenFromJs: jsMatch ? jsMatch[1] : '',
                nickname: nm ? nm[1] : '', avatar: am ? am[1] : '',
              }
            } catch (e) { return { error: e.message } }
          })
          token = pageInfo.tokenFromUrl || pageInfo.tokenFromJs || ''
          nickname = pageInfo.nickname || ''
          avatar = pageInfo.avatar || ''
        } catch (e) {}
      } else {
        try {
          const info = await executeInWechatTab(async (tk) => {
            try {
              const resp = await fetch('https://mp.weixin.qq.com/cgi-bin/home?t=home/index&token=' + tk + '&lang=zh_CN', { credentials: 'include' })
              const html = await resp.text()
              const nm = html.match(/<div class="weui-desktop-name">([^<]+)<\/div>/)
              const am = html.match(/<img[^>]+class="weui-desktop-account__img"[^>]+src="([^"]+)"/)
              return { nickname: nm ? nm[1] : '', avatar: am ? am[1] : '' }
            } catch { return { nickname: '', avatar: '' } }
          }, [token])
          nickname = info.nickname || ''
          avatar = info.avatar || ''
        } catch (e) {}
      }

      await chrome.storage.local.set({
        wechatToken: token,
        wechatCookie: fullCookie,
        wechatExpires: expires,
        wechatNickname: nickname,
        wechatAvatar: avatar,
      })

      closeWechatLoginWindow()
      return { token, nickname, avatar, expires }
    }

    case 'wechat_login_cancel': {
      closeWechatLoginWindow()
      return { ok: true }
    }

    case 'wechat_logout': {
      closeWechatLoginWindow()
      await authManager.disconnect('wechat')
      return { ok: true }
    }

    // ========== 小红书登录 ==========

    // ========== 快手登录（已禁用：使用 inject_execute 策略，Cookie 自动带上） ==========
    // 保留 kuaishou_fetch 用于移动端 UA fetch

    default:
      return { error: `Unknown message type: ${msg.type}` }
  }
}

// ============================================================================
// 9. 事件监听
// ============================================================================

chrome.windows.onRemoved.addListener((windowId) => {
  if (windowId === wechatLoginWindowId) {
    wechatLoginTabId = null
    wechatLoginWindowId = null
  }
})

chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === wechatLoginTabId) {
    wechatLoginTabId = null
    wechatLoginWindowId = null
  }
})

