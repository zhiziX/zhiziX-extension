# 可选权限说明（Optional Permissions FAQ）

## 用户常见问题

### Q1: 如何授权 AI 功能？

**最简单的方式**：
1. 点击浏览器工具栏的扩展图标
2. 在弹出的窗口中点击"授权 AI 功能"按钮
3. 浏览器会弹窗请求权限，点击"允许"即可

授权后，popup 会显示"✓ 已授权 AI 功能"。

### Q2: 为什么扩展请求"访问所有网站的数据"？

**简短回答**：为了让你能使用任何 AI API 提供商。

**详细说明**：
- 你可能使用 OpenAI、Claude、Gemini、DeepSeek 等不同的 AI 服务
- 你可能使用第三方代理或自建 API
- 我们无法预知所有可能的 API 域名，所以需要通配符权限

### Q2: 这个权限会被滥用吗？

**不会。原因：**
1. 扩展只在你主动使用 AI 写作功能时才发送请求
2. 请求只发送到你自己配置的 API 地址
3. 扩展不会访问你浏览的其他网站
4. 代码开源，可以审查

### Q3: 如果我拒绝这个权限会怎样？

**其他功能完全正常**：
- ✅ 媒体解析（B站、抖音、小红书）正常使用
- ✅ 公众号采集正常使用
- ❌ AI 写作功能无法使用

### Q4: Popup 界面有什么功能？

点击扩展图标后，会看到管理界面，包含：

1. **权限管理**：显示授权状态，一键授权 AI 功能
2. **平台连接**：查看微信、B站、抖音等平台的登录状态
3. **AI 任务监控**：实时显示正在处理的 AI 任务
4. **快捷操作**：
   - 打开网页应用
   - 清理已完成的任务缓存
5. **模型统计**：查看每个 AI 模型的调用次数

所有数据都存储在本地，不上传服务器。

### Q5: 我的 API Key 会被上传吗？

**不会**：
- API Key 存储在你的浏览器本地（localStorage）
- 扩展直接用你的 Key 调用 AI API
- 不经过我们的服务器
- 我们看不到你的 Key 和对话内容

### Q5: 为什么不把常见 AI API 域名写死在权限里？

**因为限制太多**：
- 用户可能使用自建代理（如 `https://my-proxy.example.com`）
- 企业用户可能使用内网 API（如 `https://ai.company.internal`）
- 第三方代理域名五花八门
- 写死域名会导致很多用户无法使用

## 技术实现

### 权限使用位置

**代码文件**：`extension/background.js`
**函数**：`processAiTask`（第 342-369 行）

```javascript
async function processAiTask(taskId) {
  // ... 省略前置代码
  const { url, method = 'POST', headers = {}, body } = task.request
  const resp = await fetch(url, { method, headers, body: body || undefined })
  // ... 省略后续代码
}
```

**关键点**：
- `url` 是用户在 AI Keychain 中配置的 API 端点
- 扩展只是透明转发，不解析请求内容
- 响应直接返回给网页，扩展不保存

### 数据流向

```
用户网页 → chrome.runtime.sendMessage → 扩展 background.js
→ fetch(用户配置的API地址) → AI API 服务器
→ 响应返回 → 扩展 → 用户网页
```

**全程不经过智子X服务器**

## 对比其他方案

### 方案A：服务器代理（我们拒绝）
```
用户 → 智子X服务器 → AI API
```
❌ 你的 API Key 会经过我们的服务器
❌ 你的对话内容会经过我们的服务器
❌ 多用户共享 IP，容易被 AI 提供商封禁

### 方案B：写死常见域名（不够灵活）
```
"host_permissions": [
  "https://api.openai.com/*",
  "https://api.anthropic.com/*",
  ...
]
```
❌ 无法支持第三方代理
❌ 无法支持企业内网 API
❌ 新的 AI 提供商需要更新扩展

### 方案C：可选权限（我们的选择）
```
"optional_host_permissions": ["https://*/*"]
```
✅ 支持所有 HTTPS API
✅ 用户明确授权
✅ 可以随时撤销
✅ 不影响其他功能

## 如何验证扩展的行为

### 方法1：查看网络请求
1. 打开 Chrome DevTools（F12）
2. 切换到 Network 标签
3. 使用 AI 写作功能
4. 你会看到请求直接发送到你配置的 API 地址

### 方法2：查看源代码
- GitHub 仓库：https://github.com/zhiziX/zhizix-extension
- 扩展代码：`src/background.js`
- 搜索 `processAiTask` 函数

### 方法3：检查本地存储
1. 打开 Chrome DevTools（F12）
2. Application → Local Storage
3. 查看 `aiKeychain` 相关数据
4. 你的 API Key 就存储在这里，没有上传

## 撤销权限

如果你不再使用 AI 写作功能，可以随时撤销权限：

1. 右键点击扩展图标
2. 选择"管理扩展"
3. 找到"网站访问权限"
4. 改为"点击后"或"特定网站"

撤销后，媒体解析和公众号采集功能仍然正常使用。
