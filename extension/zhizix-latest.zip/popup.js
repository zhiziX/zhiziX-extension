// ============================================================================
// 1. 权限授权
// ============================================================================

const authStatusEl = document.getElementById('authStatus');
const authBtn = document.getElementById('authBtn');

async function checkPermission() {
  const hasPermission = await chrome.permissions.contains({ origins: ['https://*/*'] });

  if (hasPermission) {
    authStatusEl.textContent = '✓ 已授权 AI 功能';
    authStatusEl.className = 'status-box success';
    authBtn.textContent = '已授权';
    authBtn.disabled = true;
  } else {
    authStatusEl.textContent = '⚠ 需要授权才能使用 AI 功能';
    authStatusEl.className = 'status-box warning';
    authBtn.textContent = '授权 AI 功能';
    authBtn.disabled = false;
  }
}

authBtn.addEventListener('click', async () => {
  try {
    const granted = await chrome.permissions.request({ origins: ['https://*/*'] });
    if (granted) {
      await checkPermission();
    } else {
      alert('授权被拒绝，AI 功能将无法使用');
    }
  } catch (err) {
    console.error('授权失败:', err);
    alert('授权失败: ' + err.message);
  }
});

// ============================================================================
// 2. 快捷操作
// ============================================================================

document.getElementById('openApp').addEventListener('click', () => {
  chrome.tabs.create({ url: 'https://zhizix.com' });
});

document.getElementById('clearCache').addEventListener('click', async () => {
  if (confirm('确定要清理所有已完成的任务缓存吗？')) {
    try {
      const response = await chrome.runtime.sendMessage({ type: 'list_ai_tasks' });
      const tasks = response?.tasks || {};

      for (const [id, task] of Object.entries(tasks)) {
        if (task.status === 'completed' || task.status === 'failed') {
          await chrome.runtime.sendMessage({ type: 'delete_ai_task', taskId: id });
        }
      }

      alert('缓存清理完成');
    } catch (err) {
      alert('清理失败: ' + err.message);
    }
  }
});

// ============================================================================
// 3. 模型调用统计
// ============================================================================

const statList = document.getElementById('statList');
const STATS_PAGE_SIZE = 10;
let statsShowAll = false;

async function loadStats() {
  try {
    const { modelStats = {} } = await chrome.storage.local.get('modelStats');
    const entries = Object.entries(modelStats).sort((a, b) => b[1].count - a[1].count);

    if (entries.length === 0) {
      statList.innerHTML = '<div class="empty">暂无统计数据</div>';
      return;
    }

    const displayEntries = statsShowAll ? entries : entries.slice(0, STATS_PAGE_SIZE);
    const hasMore = entries.length > STATS_PAGE_SIZE;

    statList.innerHTML = displayEntries.map(([model, stat]) => {
      const tokens = stat.tokens?.total || 0;
      const tokensText = tokens > 0 ? ` · ${formatTokens(tokens)}` : '';
      return `
        <div class="stat-item">
          <span class="name">${model}</span>
          <span class="value">${stat.count} 次${tokensText}</span>
        </div>
      `;
    }).join('');

    if (hasMore && !statsShowAll) {
      statList.innerHTML += `
        <div class="stat-item" id="showMoreStats" style="cursor: pointer; justify-content: center; color: #1976d2;">
          查看更多 (${entries.length - STATS_PAGE_SIZE} 个模型)
        </div>
      `;
      document.getElementById('showMoreStats')?.addEventListener('click', () => {
        statsShowAll = true;
        loadStats();
      });
    } else if (statsShowAll && hasMore) {
      statList.innerHTML += `
        <div class="stat-item" id="showLessStats" style="cursor: pointer; justify-content: center; color: #1976d2;">
          收起
        </div>
      `;
      document.getElementById('showLessStats')?.addEventListener('click', () => {
        statsShowAll = false;
        loadStats();
      });
    }
  } catch (err) {
    console.error('加载统计失败:', err);
    statList.innerHTML = '<div class="empty">加载失败</div>';
  }
}

function formatTokens(tokens) {
  if (tokens >= 1000000) return (tokens / 1000000).toFixed(1) + 'M';
  if (tokens >= 1000) return (tokens / 1000).toFixed(1) + 'K';
  return tokens.toString();
}

document.getElementById('clearStats').addEventListener('click', async () => {
  if (confirm('确定要清空所有模型统计数据吗？此操作不可恢复。')) {
    try {
      await chrome.storage.local.remove('modelStats');
      await loadStats();
      alert('统计数据已清空');
    } catch (err) {
      alert('清空失败: ' + err.message);
    }
  }
});

// ============================================================================
// 初始化
// ============================================================================

async function init() {
  await checkPermission();
  await loadStats();
}

init();
