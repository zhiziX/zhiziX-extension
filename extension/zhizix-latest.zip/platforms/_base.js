/**
 * 平台适配器接口定义
 *
 * 每个平台（B站、抖音、小红书、微信）需要实现此接口。
 * 新增平台时，在 auth-manager.js 的 _registerBuiltinPlatforms() 中注册即可。
 *
 * @typedef {Object} PlatformAdapter
 *
 * @property {string} id
 *   平台唯一标识，如 'bilibili'、'douyin'
 *
 * @property {string} name
 *   平台中文名，如 '哔哩哔哩'
 *
 * @property {string} domain
 *   平台主域名，用于标签页匹配，如 'www.bilibili.com'
 *
 * @property {string} homeUrl
 *   平台首页 URL，用于打开登录标签页
 *
 * @property {string} cookieUrl
 *   读取 cookie 的 URL，传给 chrome.cookies.getAll({ url })
 *
 * @property {'cookie_fetch' | 'inject_execute'} strategy
 *   请求策略：
 *   - cookie_fetch：直接在 Service Worker 中 fetch，手动附加 Cookie 头（适用于简单 API，如 B站）
 *   - inject_execute：注入平台页面执行，复用平台自身的签名逻辑（适用于有加密签名的平台，如抖音/小红书）
 *
 * @property {function(string): {loggedIn: boolean, username?: string, avatar?: string}} checkLogin
 *   检查用户是否已登录。参数为拼接好的 cookie 字符串。
 *   通过检测特征 cookie 判断登录状态（如 B站的 DedeUserID）。
 *
 * @property {function(string, object): Record<string, string>} buildHeaders
 *   为代理请求构建 HTTP 头。参数：cookie 字符串、原始请求对象。
 *   返回包含 Cookie、Referer 等必要头的对象。
 *
 * @property {function({ensureTab: function, executeInTab: function}): Promise<object>} [onConnect]
 *   可选。自定义连接流程（如微信的扫码登录）。
 *   如果不提供，默认行为是打开平台首页让用户手动登录。
 *   helpers.ensureTab(platformId) — 确保平台标签页存在并返回 tabId
 *   helpers.executeInTab(platformId, func, args) — 在平台标签页中执行函数
 */

/**
 * 适配器模板示例（复制此模板创建新平台适配器）：
 *
 * {
 *   id: 'example',
 *   name: '示例平台',
 *   domain: 'www.example.com',
 *   homeUrl: 'https://www.example.com/',
 *   cookieUrl: 'https://www.example.com/',
 *   strategy: 'cookie_fetch',
 *
 *   checkLogin(cookieStr) {
 *     const loggedIn = cookieStr.includes('session_id=')
 *     return { loggedIn }
 *   },
 *
 *   buildHeaders(cookieStr) {
 *     return {
 *       'Cookie': cookieStr,
 *       'Referer': 'https://www.example.com/',
 *     }
 *   },
 * }
 */

export default {}
